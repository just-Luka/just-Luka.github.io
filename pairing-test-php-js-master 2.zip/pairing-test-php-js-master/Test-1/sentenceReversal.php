<?php

declare(strict_types=1);

final readonly class Reversal
{
    public function sentenceReversal(string $sentence): string
    {
        if (! $this->validation($sentence)) {
            return '';
        };

        return strrev($sentence);
    }

    public function validation(string $sentence, array $requiredPrefix = ['.', '?', '!']): bool
    {
        $len = strlen($sentence);

        return strtoupper($sentence[0]) !== $sentence[0] ||
            !in_array($sentence[$len - 1], $requiredPrefix) ||
            trim($sentence) === "";
    }

    public function validationFails2(string $sentence)
    {
        ### Regex
    }
}

$instance = new Reversal();
$instance->sentenceReversal('First!');