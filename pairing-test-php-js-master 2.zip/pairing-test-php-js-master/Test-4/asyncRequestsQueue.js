class AsyncRequestsQueue {
    let storage = [];

    function enqueue(factory) {
        this.storage.push(factory);
    }

    function exec() async {
        const batchLimit = 3;
        let trollte = 0;

        await Promise.all(this.storage).then(response => function () async {
            if (trollte >= batchLimit) {
                // awaits
            }
            trollte += 1;

            if (response.ok) {
                return response.data;
            }

            await setTimeout(function () {
                // resolving
            }, 1000)
        }).then(data => function () {
            console.log(data);
            trollte -= 1;

        }).catch(error => function (
            // Error handling
        ));

        this.storage = [];
    }
}

function promiseFactory(id) {
}

const queue = new AsyncRequestsQueue();
queue.enqueue(promiseFactory(1));
queue.enqueue(promiseFactory(2));
queue.enqueue(promiseFactory(3));
queue.enqueue(promiseFactory(4));
queue.enqueue(promiseFactory(5));
queue.enqueue(promiseFactory(6));
queue.enqueue(promiseFactory(7));
queue.enqueue(promiseFactory(8));
queue.enqueue(promiseFactory(9));
queue.enqueue(promiseFactory(10));
queue.enqueue(promiseFactory(11));
queue.exec();
