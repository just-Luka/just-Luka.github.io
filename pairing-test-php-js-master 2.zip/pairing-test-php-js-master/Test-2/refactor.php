<?php

# Refactor the following function for better readability. 
# The code must give the same results after refactoring.

function fibonacci(int $n)
{
    if ($n < 50) {
        if ($n !== 0) {
            if ($n !== 1) {
                return fibonacci($n - 1) + fibonacci($n - 2);
            }
            return 1;
        }
        return 0;
    }
    return 'Not supported';
}

function fibonacciRecursive(int $n): string|int
{
    if ($n >= 50) {
        return 'Not supported';
    }

    if (in_array($n, [0, 1])) {
        return $n;
    }

    return fibonacciRecursive($n - 1) + fibonacciRecursive($n - 2);
}


echo "\n\n\nOriginal function result " . fibonacci(10) . "\n\n\n";
echo "\n\n\Refactored function result " . fibonacciRecursive(10) . "\n\n\n";