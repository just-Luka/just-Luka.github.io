<?php

declare(strict_types=1);

#Implement a Calculator App that supports different arithmetic operations (Add, Subtract, Divide and Multiply).
# Use the Strategy design pattern to allow the operation method to be selected dynamically at runtime.


interface Operations
{
    public function add(float $a): self;
    public function subtract(float $a): self;
    public function multiply(float $a): self;
    public function divide(float $a): self;
}

interface subCommands
{
    public function reset(): void;
    # public function undo(): void;
}

interface Strategy extends Operations, SubCommands
{
    public function calculate(): float;
}

final class Calculator implements Strategy
{
    public function __construct(
        private float $number = 0,
    ) {}

    public function add(float $a): self
    {
        $this->number += $a;
        return $this;
    }

    public function subtract(float $a): self
    {
        $this->number -= $a;
        return $this;
    }

    public function multiply(float $a): self
    {
        $this->number *= $a;
        return $this;
    }

    public function divide(float $a): self
    {
        $this->number /= $a;
        return $this;
    }

    public function calculate(): float
    {
        return $this->number;
    }

    public function reset(): void
    {
        $this->number = 0;
    }
}

echo (new Calculator(15))->add(10)->subtract(5)->calculate();