# Test goal

Write a program that will receive a sentence as an input. 

## 1. Input validation functionality:

A sentence may contain one or more words, each one consisting of one or more letters.

### Validation criteria:

 - A valid sentence starts with a capital letter.
 - A valid sentence ends with either:
    a dot (.) character,
    a question mark (?) character
    an exclamation mark (!) character
 - There are only single white spaces between words.


### Validation functionality

 - If the validation fails the program outputs 'The sentence is invalid.' and the execution stops.
 - Otherwise, the program outputs 'The sentence valid.' 


## 2. Sentence reversal functionality:

The program aims to reverse the sequence of the words in a sentence

### Reversal functionality

    - The input sensence need to be changed so that it is build by reversing the order of the words. 
    - The first letter of the first word of the reversed sentence needs to be capital.
    - The dot, question mark, or exclamation mark, needs to be placed after the last word.

The program outputs the reversed sentence.



## A few examples (Validation functionality):

Input: The quick brown fox jumps over the lazy dog.
Output: Sentence is valid

Input: The quick brown fox jumps over the lazy dog
Output: Sentence is invalid

Input: How vexingly quick daft zebras jump!
Output: Sentence is valid

Input: How vexingly quick  daft zebras jump!
Output: Sentence is invalid
There is a double space between the words 'quick' and 'daft'

2. A sentence built by reversing the order of the words. 
 - The dot / question mark / exclamation mark character needs to remain at the end.
 - The first letter of the first word needs to be capital
 - The first letter of the last word needs to be lowercase

## A few examples (reversal functionality):

Input: The quick brown fox jumps over the lazy dog.
Output: Dog lazy the over jumps fox brown quick the.

Input: How vexingly quick daft zebras jump!
Output: Jump zebras daft quick vexingly how!

