# Async requests queue

## Description
Write a program that consists of a queue that can handle async requests. 
You have to pass a promise factory to the queue.
When the queue calls the promise factory, your job gets to execute.

## Constraints
- The queue order must be executed in FIFO(first in first out).
- The requests running in the queue must be non blocking (e.g request 2 should not wait for request 1 to finish).
- The async requests queue can only have up to 3 running tasks at any given time.
- When less than 3 tasks are running, the queue should execute the next task in the queue.
- The promise should have random delay before resolving in the range of 1000ms to 2000ms.
